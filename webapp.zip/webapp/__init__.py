from flask import Flask, render_template, Response
from flask_socketio import SocketIO, emit
import serial
from picamera.array import PiRGBArray
from picamera import PiCamera
import time
import cv2
import numpy as np
from threading import Thread

import math
import struct


AUTO_STATE = 0
manual_state = 0
mode = 0
# blue_percentage = 0

latest_video_frame = []
cycles_without_web_contact = 0

# dictionary for converting serial incoming data regarding the current manual state:
manual_states = {
    0: "Stop",
    1: "Forward",
    2: "Backward",
    3: "Right",
    4: "Left"
}

# dictionary for converting serial incoming data regarding the current mode:
mode_states = {
    5: "Manual",
    6: "Auto"
}

# initialize serial communication with the arduino: (9600 is the baudrate, should match serial baudrate in arduino)
serial_port = serial.Serial("/dev/ttyACM0", 9600) 
time.sleep(2)   # this is required because the arduino resets when a serial connection is established

# initialize the web server:
app = Flask(__name__)
socketio = SocketIO(app, async_mode = "threading") # without "async_mode = "threading", sending stuff to the cliend (via socketio) doesn't work!

# check user input for new Kp and/or Kd values:
# def check_parameter_input(value):    
#     if value:
#         try:
#             value = int(value)
#         except:
#             value = "" # value must be an integer! (so don't send the parameter to the arduino)
#             return value
#         else: # if conversion was successful:
#             if value < 0:
#                 value = "" # value must be positive! (so don't send the parameter to the arduino)
#                 return value
#             else: # if positive integer
#                 return value # (everything is OK, send the parameter)        
#     else: # if value == 0 or value is empty (if the parameter field was left empty)
#         return value

font = cv2.FONT_HERSHEY_SIMPLEX
direction = 0
Images=[]
N_SLICES = 4










class Image:
    
    def __init__(self):
        self.image = None
        self.contourCenterX = 0
        self.MainContour = None
        
    def Process(self):
        imgray = cv2.cvtColor(self.image,cv2.COLOR_BGR2GRAY) #Convert to Gray Scale
        ret, thresh = cv2.threshold(imgray,100,255,cv2.THRESH_BINARY_INV) #Get Threshold

        kernel = np.ones((3,3), np.uint8)
        thresh = cv2.erode(thresh, kernel, iterations=2)

        _, self.contours, _ = cv2.findContours(thresh,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE) #Get contour
        
        self.prev_MC = self.MainContour
        if self.contours:
            self.MainContour = max(self.contours, key=cv2.contourArea)
        
            self.height, self.width  = self.image.shape[:2]

            self.middleX = int(self.width/2) #Get X coordinate of the middle point
            self.middleY = int(self.height/2) #Get Y coordinate of the middle point
            
            self.prev_cX = self.contourCenterX
            
            if self.getContourCenter(self.MainContour) != 0:
                self.contourCenterX = self.getContourCenter(self.MainContour)[0] # acquire X coordinate
                if abs(self.prev_cX-self.contourCenterX) > 5: #??? 
                    self.correctMainContour(self.prev_cX)
            else:
                self.contourCenterX = 0
            
            self.dir =  int((self.middleX-self.contourCenterX) * self.getContourExtent(self.MainContour)) # что даёт это умножение?
            
            cv2.drawContours(self.image,self.MainContour,-1,(0,255,0),3) #Draw Contour GREEN
            cv2.circle(self.image, (self.contourCenterX, self.middleY), 7, (0,0,255), -1) #Draw dX circle WHITE
            cv2.circle(self.image, (self.middleX, self.middleY), 5, (255,0,0), -1) #Draw middle circle RED
            
            font = cv2.FONT_HERSHEY_SIMPLEX
            cv2.putText(self.image,str(self.middleX-self.contourCenterX),(self.contourCenterX+20, self.middleY), font, 0.4,(200,0,200),1,cv2.LINE_AA)
            cv2.putText(self.image,"Weight:%.3f"%self.getContourExtent(self.MainContour),(self.contourCenterX+10, self.middleY+15), font, 0.3,(200,0,200),1,cv2.LINE_AA)
        
    def getContourCenter(self, contour):
        M = cv2.moments(contour)
        
        if M["m00"] == 0:
            return 0
        
        x = int(M["m10"]/M["m00"])
        y = int(M["m01"]/M["m00"])
        
        return [x,y]
        
    def getContourExtent(self, contour): # это похоже на отношение захваченного контура черной линии к охватывающему его прямоугольнику
        area = cv2.contourArea(contour)
        x,y,w,h = cv2.boundingRect(contour)
        rect_area = w*h
        if rect_area > 0:
            return (float(area)/rect_area)
            
    def Aprox(self, a, b, error):
        if abs(a - b) < error:
            return True
        else:
            return False
            
    def correctMainContour(self, prev_cx): # это в процессе езды он смещается или что?
        if abs(prev_cx-self.contourCenterX) > 5:
            for i in range(len(self.contours)):
                if self.getContourCenter(self.contours[i]) != 0:
                    tmp_cx = self.getContourCenter(self.contours[i])[0]
                    if self.Aprox(tmp_cx, prev_cx, 5) == True:
                        self.MainContour = self.contours[i]
                        if self.getContourCenter(self.MainContour) != 0:
                            self.contourCenterX = self.getContourCenter(self.MainContour)[0]


for q in range(N_SLICES):
    Images.append(Image()) # what??






def my_map(x, in_min = -600, in_max = 600, out_min = -128, out_max = 126):
    return int((x-in_min) * (out_max-out_min) / (in_max-in_min) + out_min)

def my_constrain(val, min_val = -128, max_val = 126):
    return min(max_val, max(min_val, val))

def SlicePart(im, images, slices):
    height, width = im.shape[:2] # до третьего значения -- слоёв цвета -- не включая
    sl = int(height/slices);
    
    for i in range(slices):
        part = sl*i
        crop_img = im[part:part+sl, 0:width]
        images[i].image = crop_img
        images[i].Process()
    
def RepackImages(images):
    img = images[0].image 
    for i in range(len(images)):
        if i == 0:
            # img = np.concatenate((img, images[1].image), axis=0)
            img = np.vstack((img, images[1].image))
        if i > 1:
            # img = np.concatenate((img, images[i].image), axis=0)
            img = np.vstack((img, images[i].image))       
    return img

def getContourCenter(self, contour):
    M = cv2.moments(contour)

    if M["m00"] == 0:
        return 0

    x = int(M["m10"]/M["m00"])
    y = int(M["m01"]/M["m00"])

    return [x,y]
    
def RemoveBackground(image, b):
    global up
    up = 30
    # create NumPy arrays from the boundaries
    lower = np.array([0, 0, 0], dtype = "uint8")
    upper = np.array([up, up, up], dtype = "uint8")
    #----------------COLOR SELECTION-------------- (Remove any area that is whiter than 'upper')
    if b == True:
        mask = cv2.inRange(image, lower, upper)
        image = cv2.bitwise_and(image, image, mask = mask)
        image = cv2.bitwise_not(image, image, mask = mask)
        image = (255-image)
        return image
    else:
        return image
    #////////////////COLOR SELECTION/////////////

















        
def video_thread():
    # enable the thread to modify the global variable 'latest_video_frame': (this variable will be accessed by functions doing some sort of video analysis or video streaming)
    global latest_video_frame   
    
    # create an instance of the RPI camera class:
    camera = PiCamera() 
    
    # rotate the camera view 180 deg (I have the RPI camera mounted upside down):
    # camera.hflip = True
#     camera.vflip = True 
    
    # set resolution and frame rate:
    camera.resolution = (320, 240)
    # camera.resolution = (640, 480)
    camera.framerate = 30
    
    font = cv2.FONT_HERSHEY_SIMPLEX
    direction = 0
    Images=[]
    N_SLICES = 4

    # create a generator 'video_frame_generator' which will continuously capture video frames 
    # from the camera and save them one by one in the container 'generator_output': ('video_frame_generator' is an infinte iterator which on every iteration (every time 'next()' is called on it, like eg in a for loop) gets a video frame from the camera and saves it in 'generator_output'))  
    generator_output = PiRGBArray(camera, size=(320, 240))
    # generator_output = PiRGBArray(camera, size=(640, 480))

    video_frame_generator = camera.capture_continuous(generator_output, format="bgr", use_video_port=True)
    
    # allow the camera to warm up:
    time.sleep(0.1)
    
    for item in video_frame_generator:
        # get the numpy array representing the latest captured video frame from the camera
        # and save it globally for everyone to access:
        latest_video_frame = generator_output.array 
        
        # clear the output container so it can store the next frame in the next loop cycle:
        # (please note that this is absolutely necessary!)
        generator_output.truncate(0)        
        
        # delay for 0.033 sec (for ~ 30 Hz loop frequency):
        time.sleep(0.033) 
        
# stop the robot if the wifi connection is lost: (by telling the arduino to do so over serial)
def stop_runaway_robot():
    # set mode to manual and manual_state to stop: (and everything else to the maximum number for their data type to mark that they are not to be read)
    start_byte = np.uint8(100)
    manual_state = np.uint8(0)
    mode = np.uint8(5)
#     Kp = np.uint8(0xFF)
#     Kd = np.uint16(0xFFFF)
#     Kd_low = np.uint8((Kd & 0x00FF))
#     Kd_high = np.uint8((Kd & 0xFF00)/256)
    
    # caculate checksum for the data bytes to be sent:
#     checksum = np.uint8(manual_state + mode + Kp + Kd_low + Kd_high)
    checksum = np.uint8(manual_state + mode)
    
    # send all data bytes:
    # serial_port.write(start_byte.tobytes())
    # serial_port.write(manual_state.tobytes())
    # serial_port.write(mode.tobytes())
#     serial_port.write(Kp.tobytes())
#     serial_port.write(Kd_low.tobytes())
#     serial_port.write(Kd_high.tobytes())
    
    # send checksum:
    # serial_port.write(checksum.tobytes())

def web_thread():
    global cycles_without_web_contact
    
    while 1:
        # send all data for display on the web page:
#         socketio.emit("new_data", {"IR_0": IR_0, "IR_1": IR_1, "IR_2": IR_2, "IR_3": IR_3, "IR_4": IR_4, "IR_Yaw_right": IR_Yaw_right, "IR_Yaw_left": IR_Yaw_left, "Yaw": Yaw, "p_part": p_part, "alpha": alpha, "Kp": Kp, "Kd": Kd, "AUTO_STATE": AUTO_STATE, "manual_state": manual_state, "mode": mode, "blue_percentage": blue_percentage})
        socketio.emit("new_data", {"AUTO_STATE": AUTO_STATE, "manual_state": manual_state, "mode": mode})        
        cycles_without_web_contact += 1
        if cycles_without_web_contact > 5: # if we havn't had wifi contact for ~ 0.5 sec: stop the robot!
            stop_runaway_robot()
        # delay for 0.1 sec (for ~ 10 Hz loop frequency):
        time.sleep(0.1) 
        
# def read_serial_thread():
#     # all global variables this function can modify:
# #     global IR_0, IR_1, IR_2, IR_3, IR_4, IR_Yaw_right, IR_Yaw_left, Yaw, p_part, alpha, Kp, Kd, AUTO_STATE, manual_state, mode, blue_percentage
#     global AUTO_STATE, manual_state, mode

#     while 1:
#         no_of_bytes_waiting = serial_port.inWaiting()
#         if no_of_bytes_waiting > 19: # the ardu sends 20 bytes at the time (18 data, 2 control) СКОЛЬКО ПОСЫЛАЕМ С АРДУИНО
#             # read the first byte (read 1 byte): (ord: gives the actual value of the byte) ___________________
#             first_byte = np.uint8(ord(serial_port.read(size = 1))) 
            
#             # read all data bytes if first byte was the start byte:
#             if first_byte == 100:
#                 serial_data = []
#                 # read all data bytes:
#                 for counter in range(18): # 18 data bytes is sent from the ardu ___________________
#                     serial_data.append(ord(serial_port.read(size = 1)))
                
#                 # read the received checksum:
#                 checksum = np.uint8(ord(serial_port.read(size = 1)))
                
#                 # calculate checksum for the received data bytes: (pleae note that the use of uint8 and int8 exactly match what is sent from the arduino)
# #                 calc_checksum = np.uint8(np.uint8(serial_data[0]) + np.uint8(serial_data[1]) + 
# #                     np.uint8(serial_data[2]) + np.uint8(serial_data[3]) + np.uint8(serial_data[4]) + 
# #                     np.int8(serial_data[5]) + np.int8(serial_data[6]) + np.int8(serial_data[7]) + 
# #                     np.int8(serial_data[8]) + np.int8(serial_data[9]) + np.int8(serial_data[10]) + 
# #                     np.uint8(serial_data[11]) + np.uint8(serial_data[12]) + np.uint8(serial_data[13]) + 
# #                     np.uint8(serial_data[14]) + np.uint8(serial_data[15]) + np.uint8(serial_data[16]) + np.uint8(serial_data[17]))
# # ----------------------
#                 calc_checksum = np.uint8(np.uint8(serial_data[0]) + np.uint8(serial_data[1]) + 
#                     np.uint8(serial_data[2]) + np.uint8(serial_data[3]) + np.uint8(serial_data[4]) + 
#                     np.int8(serial_data[5]) + np.int8(serial_data[6]) + np.int8(serial_data[7]) + 
#                     np.int8(serial_data[8]) + np.int8(serial_data[9]) + np.int8(serial_data[10]) + 
#                     np.uint8(serial_data[11]) + np.uint8(serial_data[12]) + np.uint8(serial_data[13]) + 
#                     np.uint8(serial_data[14]) + np.uint8(serial_data[15]) + np.uint8(serial_data[16]) + np.uint8(serial_data[17]))
                
#                 # update the variables with the read serial data only if the checksums match:
#                 if calc_checksum == checksum:
# #                     IR_0 = int(np.uint8(serial_data[0])) # (int() is needed to convert it to something that can be sent to the webpage) 
# #                     IR_1 = int(np.uint8(serial_data[1]))
# #                     IR_2 = int(np.uint8(serial_data[2]))
# #                     IR_3 = int(np.uint8(serial_data[3]))
# #                     IR_4 = int(np.uint8(serial_data[4]))
# #                     IR_Yaw_right = int(np.int8(serial_data[5])) # IR_Yaw_right was sent as an int8_t, but in order to make python treat it as one we first need to tell it so explicitly with the help of numpy, before converting the result (a number between -128 and +127) to the corresponding python int 
# #                     IR_Yaw_left = int(np.int8(serial_data[6]))
# #                     Yaw = int(np.int8(serial_data[7]))
# #                     p_part = int(np.int8(serial_data[8]))
# #                     alpha_low_byte = np.uint8(serial_data[9])
# #                     alpha_high_byte = np.uint8(serial_data[10]) # yes, we need to first treat both the low and high bytes as uint8:s, try it by hand and a simple example (try sending -1)
# #                     alpha = int(np.int16(alpha_low_byte + alpha_high_byte*256)) # (mult with 256 corresponds to a 8 bit left shift)
# #                     Kp = int(np.uint8(serial_data[11]))
# #                     Kd_low_byte = np.uint8(serial_data[12])
# #                     Kd_high_byte = np.uint8(serial_data[13])
# #                     Kd = int(Kd_low_byte + Kd_high_byte*256)
#                     AUTO_STATE = auto_states[int(np.uint8(serial_data[14]))] # look up the received integer in the auto_states dict
#                     manual_state = manual_states[int(np.uint8(serial_data[15]))] # ___________________
#                     mode = mode_states[int(np.uint8(serial_data[16]))]
# #                     blue_percentage = int(np.uint8(serial_data[17]))
#                 else: # if the checksums doesn't match: something weird has happened during transmission: flush input buffer and start over
#                     serial_port.flushInput()
#                     print("Something went wrong in the transaction: checksums didn't match!")                      
#             else: # if first byte isn't the start byte: we're not in sync: just read the next byte until we get in sync (until we reach the start byte)
#                 pass
#         else: # if not enough bytes for entire transmission, just wait for more data:
#             pass

#         time.sleep(0.025) # Delay for ~40 Hz loop frequency (faster than the sending frequency)



# def gen_normal():
#     while 1:
#         if len(latest_video_frame) > 0: # if we have started receiving actual frames:
#             # convert the latest read video frame to jpg format:
#             ret, jpg = cv2.imencode(".jpg", latest_video_frame) 
            
#             # get the raw data bytes of the jpg image: (convert to binary)
#             frame = jpg.tobytes()
            
#             # yield ('return') the frame: (yield: returns value and saves the current state of the generator function, the next time this generator function is called execution will resume on the next line of code in the function (ie it will in this example start a new cycle of the while loop and yield a new frame))
#             # what we yield looks like this, but in binary: (binary data is a must for multipart)
#             # --frame
#             # Content-Type: image/jpeg
#             #
#             # <frame data>
#             #
#             yield (b'--frame\nContent-Type: image/jpeg\n\n' + frame + b'\n')
                







def gen_mask():
    while 1:
        if len(latest_video_frame) > 0: # if we have started receiving actual frames:
            # convert the latest read video frame to HSV (Hue, Saturation, Value) format:

            img = RemoveBackground(latest_video_frame, True) # здесь не будет проблем с областью видимости имени и не потрём ничего?

            direction = 0
            t1 = time.clock()
            SlicePart(img, Images, N_SLICES) # здесь происходит вызов функции Process

            for i in range(N_SLICES):
                direction += Images[i].dir

            fm = RepackImages(Images)
            t2 = time.clock()
            setpoint = my_constrain(my_map(direction))


            cv2.putText(fm,"filter: erode",(10, 130), font, 0.3,(150,150,0),1,cv2.LINE_AA)
            cv2.putText(fm,"3x3 kernel, 2 iterations",(10, 150), font, 0.3,(150,150,0),1,cv2.LINE_AA)
            cv2.putText(fm,"Threshhold: " + str(up),(10, 170), font, 0.3,(150,0,150),1,cv2.LINE_AA)
            # cv2.putText(fm,"filter: None",(10, 130), font, 0.5,(255,0,0),1,cv2.LINE_AA)
            cv2.putText(fm,"direction: " + str(setpoint),(10, 190), font, 0.3,(255,0,0),1,cv2.LINE_AA)
            cv2.putText(fm,"Time: " + str((t2-t1)*1000) + " ms",(10, 210), font, 0.3,(0,0,255),1,cv2.LINE_AA)

            # cv2.imshow("Vision Race", fm)
            serial_port.write(struct.pack('>b', setpoint)) # H for short, it takes 2 bytes instead of 1, b - signed char (-128;127)

            
            # convert the result to jpg format:
            ret, jpg = cv2.imencode(".jpg", fm)
            
            # get the raw data bytes of the jpg image: (convert to binary)
            frame = jpg.tobytes()
            
            # yield the frame:
            # what we yield looks like this, but in binary: (binary data is a must for multipart)
            # --frame
            # Content-Type: image/jpeg
            #
            # <frame data>
            #
            yield (b'--frame\nContent-Type: image/jpeg\n\n' + frame + b'\n')
            time.sleep(0.1)
















                
# @app.route("/camera_normal")
# def camera_normal():
#     # return a Respone object with a 'gen_normal()' generator function as its data generating iterator. We send a MIME multipart message of subtype Mixed-replace, which means that the browser will read data parts (generated by gen_obj_normal) one by one and immediately replace the previous one and display it. We never close the connection to the client, pretending like we haven't finished sending all the data, and constantly keeps sending new data parts generated by gen_obj_normal.
#     # what over time will be sent to the client is the following:
#     # Content-Type: multipart/x-mixed-replace; boundary=frame
#     #
#     # --frame
#     # Content-Type: image/jpeg
#     #
#     #<jpg data>
#     #
#     # --frame
#     # Content-Type: image/jpeg
#     #
#     #<jpg data>
#     #
#     # etc, etc
#     # where each '--frame' enclosed section represents a jpg image taken from the camera that the browser will read and display one by one, replacing the previous one, thus generating a video stream
#     gen_obj_normal = gen_normal()
#     return Response(gen_obj_normal, mimetype = "multipart/x-mixed-replace; boundary=frame")
    
@app.route("/camera_mask")
def camera_mask():
    # return a Respone object with a 'gen_mask()' generator function as its data generating iterable, se "camera_normal"
    gen_obj_mask = gen_mask()
    return Response(gen_obj_mask, mimetype = "multipart/x-mixed-replace; boundary=frame")
    


@app.route("/")   
@app.route("/index")
def index():
    try:
        # start a thread constantly reading frames from the camera:
        thread_video = Thread(target = video_thread)
        thread_video.start()
        
        # start a thread constantly sending sensor/status data to the web page: 
        thread_web = Thread(target = web_thread)
        thread_web.start()
        
        # start a thread constantly reading sensor/status data from the arduino:
        # thread_read_serial = Thread(target = read_serial_thread)
        # thread_read_serial.start()
        
        return render_template("index.html") 
    except Exception as e:
        return render_template("500.html", error = str(e))

@socketio.on("my event")
def handle_my_custom_event(sent_dict):
    print("Recieved message: " + sent_dict["data"])
       
# handle data which is sent from the web page when the user are manually controlling the robot, and send it to the arduino: (the user is either pressing the direction arrows or using WASD)
@socketio.on("arrow_event")
def handle_arrow_event(sent_dict):
    print("Recieved message: " + str(sent_dict["data"]))
    
    # get manual state, set start byte and set everything else to the maximum number for their data type to mark that they are not to be read:
    start_byte = np.uint8(100)
    manual_state = np.uint8(sent_dict["data"])
    mode = np.uint8(0xFF)
#     Kp = np.uint8(0xFF)
#     Kd = np.uint16(0xFFFF)
#     Kd_low = np.uint8((Kd & 0x00FF))
#     Kd_high = np.uint8((Kd & 0xFF00)/256)
#     blue_percentage = np.uint8(0xFF)
    
    # caculate checksum for the data bytes to be sent:
#     checksum = np.uint8(manual_state + mode + Kp + Kd_low + Kd_high + blue_percentage)
    checksum = np.uint8(manual_state + mode)
    
    # send all data bytes:
    # serial_port.write(start_byte.tobytes())
    # serial_port.write(manual_state.tobytes())
    # serial_port.write(mode.tobytes())
#     serial_port.write(Kp.tobytes())
#     serial_port.write(Kd_low.tobytes())
#     serial_port.write(Kd_high.tobytes())
#     serial_port.write(blue_percentage.tobytes())
    
    # send checksum:
    # serial_port.write(checksum.tobytes())
    
# handle data which is sent from the web page when the user are switching mode (manual or auto), and send i to the arduino:
@socketio.on("mode_event")
def handle_mode_event(sent_dict):
    print("Recieved message: " + str(sent_dict["data"]))
    
    # get mode state, set start byte and set everything else to the maximum number for their data type to mark that they are not to be read:
    start_byte = np.uint8(100)
    manual_state = np.uint8(0xFF)
    mode = np.uint8(sent_dict["data"])
#     Kp = np.uint8(0xFF)
#     Kd = np.uint16(0xFFFF)
#     Kd_low = np.uint8((Kd & 0x00FF))
#     Kd_high = np.uint8((Kd & 0xFF00)/256)
#     blue_percentage = np.uint8(0xFF)
    
    # caculate checksum for the data bytes to be sent:
    checksum = np.uint8(manual_state + mode)
    
    # send all data bytes:
    # serial_port.write(start_byte.tobytes())
    # serial_port.write(manual_state.tobytes())
    # serial_port.write(mode.tobytes())
#     serial_port.write(Kp.tobytes())
#     serial_port.write(Kd_low.tobytes())
#     serial_port.write(Kd_high.tobytes())
#     serial_port.write(blue_percentage.tobytes())
    
    # send checksum:
    # serial_port.write(checksum.tobytes())
    
# handle data which is sent from the web page when the user are changing the control parameters, and send it to the arduino:
# @socketio.on("parameters_event")
# def handle_parameters_event(sent_dict):
#     Kp_input = sent_dict["Kp"]
#     Kd_input = sent_dict["Kd"]   
#     print("Recieved Kp: " + Kp_input)
#     print("Recieved Kd: " + Kd_input)
    
#     # check parameter input and set Kp, Kd to the parameter input only it it is non-empty and valid:
#     Kp_input = check_parameter_input(Kp_input) # After this, Kp_input is non-empty only if the user typed a positive (>= 0) integer into the Kp field (and thus we should send it to the arduino)
#     Kd_input = check_parameter_input(Kd_input)      
#     if (Kp_input or Kp_input == 0) and (Kd_input or Kd_input == 0): # if valid, non-empty input for both Kp and Kd: send both Kp and Kd
#         Kp = np.uint8(Kp_input)
#         Kd = np.uint16(Kd_input)
#     elif Kp_input or Kp_input == 0: # if only Kp:
#         Kp = np.uint8(Kp_input)
#         Kd = np.uint16(0xFFFF)
#     elif Kd_input or Kd_input == 0: # if only Kd:
#         Kp = np.uint8(0xFF)
#         Kd = np.uint16(Kd_input)
#     else: # if neither is valid/non-empty:
#         Kp = np.uint8(0xFF)
#         Kd = np.uint16(0xFFFF)
#     Kd_low = np.uint8((Kd & 0x00FF))
#     Kd_high = np.uint8((Kd & 0xFF00)/256)
    
#     # set start byte and set everything else to the maximum number for their data type to mark that they are not to be read:
#     start_byte = np.uint8(100)
#     manual_state = np.uint8(0xFF)
#     mode = np.uint8(0xFF)
#     blue_percentage = np.uint8(0xFF)
    
#     # caculate checksum for the data bytes to be sent:
#     checksum = np.uint8(manual_state + mode + Kp + Kd_low + Kd_high + blue_percentage)
    
#     # send all data bytes:
#     serial_port.write(start_byte.tobytes())
#     serial_port.write(manual_state.tobytes())
#     serial_port.write(mode.tobytes())
#     serial_port.write(Kp.tobytes())
#     serial_port.write(Kd_low.tobytes())
#     serial_port.write(Kd_high.tobytes())
#     serial_port.write(blue_percentage.tobytes())
    
#     # send checksum:
#     serial_port.write(checksum.tobytes())

# reset the control counter everytime we receive the control message from the web page: (if this counter ever gets to big, we know that we have lost wifi contact)
@socketio.on("control_event")
def handle_control_event(sent_dict):
    global cycles_without_web_contact
    cycles_without_web_contact = 0
        
@app.errorhandler(404)
def page_not_found(e):
    try:
        return render_template("404.html") 
    except Exception as e:
        return render_template("500.html", error = str(e))
  
##if __name__ == '__main__':
##    socketio.run(app, "169.254.74.215", 80)
    
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')